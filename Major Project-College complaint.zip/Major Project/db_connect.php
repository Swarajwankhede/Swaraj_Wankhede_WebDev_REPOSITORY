<?php
$con = mysqli_connect("localhost", "root", "", "COLLEGE_PORTAL");

if (!$con) {
    echo ("Database connection failed");
}
?>
